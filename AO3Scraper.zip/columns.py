# -*- coding: utf-8 -*-
"""Calibre custom column setup for AO3 metadata."""

from __future__ import annotations

RAW_METADATA_LABEL = 'ao3_raw_metadata'
RAW_METADATA_LOOKUP = '#ao3_raw_metadata'
RAW_METADATA_NAME = 'AO3 Raw Metadata'

CLEANED_METADATA_LABEL = 'ao3_cleaned_metadata'
CLEANED_METADATA_LOOKUP = '#ao3_cleaned_metadata'
CLEANED_METADATA_NAME = 'AO3 Cleaned Metadata'

COMMENTS_DATATYPE = 'comments'


def column_exists(db, lookup: str) -> bool:
    try:
        db.field_metadata[lookup]
        return True
    except (KeyError, AttributeError):
        return False


def ensure_custom_column(
    db,
    *,
    label: str,
    name: str,
    lookup: str,
    datatype: str = COMMENTS_DATATYPE,
) -> str:
    """Create a comments custom column if missing. Returns the column label."""
    if column_exists(db, lookup):
        return label

    db.create_custom_column(
        label,
        name,
        datatype,
        is_multiple=False,
        editable=True,
        display={},
    )
    return label


def ensure_raw_metadata_column(db) -> str:
    return ensure_custom_column(
        db,
        label=RAW_METADATA_LABEL,
        name=RAW_METADATA_NAME,
        lookup=RAW_METADATA_LOOKUP,
    )


def ensure_cleaned_metadata_column(db) -> str:
    return ensure_custom_column(
        db,
        label=CLEANED_METADATA_LABEL,
        name=CLEANED_METADATA_NAME,
        lookup=CLEANED_METADATA_LOOKUP,
    )


def ensure_plugin_columns(db) -> dict[str, str]:
    """Ensure raw + cleaned metadata columns exist. Returns label map."""
    return {
        'raw': ensure_raw_metadata_column(db),
        'cleaned': ensure_cleaned_metadata_column(db),
    }
