# -*- coding: utf-8 -*-

from PyQt5.Qt import (
    QApplication,
    QCheckBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QSize,
    Qt,
    QVBoxLayout,
    QWidget,
)

from calibre.gui2 import error_dialog, info_dialog

from calibre_plugins.ao3_scraper.columns import (
    LAYOUT_COLUMN_SPECS,
    apply_layout_columns,
    layout_columns_present,
)
from calibre_plugins.ao3_scraper.prefs import prefs


def _echo_password(widget: QLineEdit) -> None:
    try:
        widget.setEchoMode(QLineEdit.Password)
    except AttributeError:
        widget.setEchoMode(QLineEdit.EchoMode.Password)


def _hint(text: str) -> QLabel:
    label = QLabel(text)
    label.setWordWrap(True)
    return label


class ConfigWidget(QWidget):
    def __init__(self, plugin_action):
        super().__init__()
        self.plugin_action = plugin_action

        layout = QVBoxLayout()
        self.setLayout(layout)

        intro = QLabel(
            'Use this plugin on a <b>new</b> Calibre library. Search AO3, '
            'Import, Download EPUB, Simplify, and Tag Purge write to whichever '
            'library is currently open.\n\n'
            'Search uses the ao3kit checkout and Python below (same scrape / '
            'download / enrich commands as the CLI, including the '
            'host-wide AO3 rate limiter).\n\n'
            'Fanfic columns (same labels as FanFicFare): #fandom, '
            '#relationships, #collections, #wordcount, plus #originaltags '
            'for the pre-clean AO3 tags. Cleaned tags go in Calibre\'s Tags '
            'field. AO3 series membership fills Calibre\'s built-in Series '
            'column. Columns are created on import, or when you check the box '
            'below. Count Pages columns (page count / readability) are left '
            'to that plugin.'
        )
        intro.setWordWrap(True)
        layout.addWidget(intro)

        library = QGroupBox('Library')
        library_layout = QVBoxLayout(library)
        self.create_layout = QCheckBox(
            'Create missing fanfic columns in the currently open library'
        )
        self.create_layout.setChecked(False)
        self.create_layout.setToolTip(
            'Safe if the columns already exist (no-op). Use this on a new '
            'empty library before importing, or let the first import create them.'
        )
        library_layout.addWidget(self.create_layout)
        self.status = QLabel()
        self.status.setWordWrap(True)
        library_layout.addWidget(self.status)
        layout.addWidget(library)

        login = QGroupBox('AO3 login (optional)')
        login_form = QFormLayout(login)
        self.username = QLineEdit()
        self.username.setText(str(prefs.get('ao3_username') or ''))
        self.username.setPlaceholderText('or AO3_USERNAME in ao3kit .env')
        self.password = QLineEdit()
        _echo_password(self.password)
        self.password.setText(str(prefs.get('ao3_password') or ''))
        self.password.setPlaceholderText('or AO3_PASSWORD in ao3kit .env')
        pwd_row = QWidget()
        pwd_layout = QHBoxLayout(pwd_row)
        pwd_layout.setContentsMargins(0, 0, 0, 0)
        pwd_layout.addWidget(self.password)
        self.test_login_btn = QPushButton('Test login')
        self.test_login_btn.setToolTip(
            'Log in to AO3 with the username and password above (does not '
            'save settings). Uses the ao3kit checkout configured below.'
        )
        self.test_login_btn.clicked.connect(self.test_login)
        pwd_layout.addWidget(self.test_login_btn)
        login_form.addRow('Username', self.username)
        login_form.addRow('Password', pwd_row)
        self.login_status = QLabel('')
        self.login_status.setWordWrap(True)
        login_form.addRow(self.login_status)
        login_form.addRow(
            _hint(
                'Used for Search AO3, EPUB download, tag simplification, and '
                'background tag cache. Leave both blank for anonymous access, '
                'or to use credentials from the ao3kit project .env file. '
                'Stored in this plugin\'s Calibre preferences. Click Test '
                'login to confirm the account before saving.'
            )
        )
        layout.addWidget(login)

        defaults = QGroupBox('Search and import defaults')
        defaults_form = QFormLayout(defaults)
        self.max_results = QLineEdit()
        self.max_results.setText(str(prefs.get('last_max_results') or '25'))
        self.max_results.setPlaceholderText('25')
        self.max_results.setToolTip(
            'Default cap for Search AO3. The search dialog still lets you '
            'change this per run.'
        )
        defaults_form.addRow('Default max results', self.max_results)

        self.download_epubs = QCheckBox('Download native EPUBs into this library')
        self.download_epubs.setChecked(bool(prefs.get('download_epubs', True)))
        self.download_epubs.setToolTip(
            'Default for Search AO3. Uncheck in the search dialog for a '
            'one-off metadata-only import.'
        )
        defaults_form.addRow(self.download_epubs)

        self.simplify_tags = QCheckBox(
            'Simplify tags (AO3 canonical + user rules via ao3kit)'
        )
        self.simplify_tags.setChecked(bool(prefs.get('simplify_tags', False)))
        self.simplify_tags.setToolTip(
            'Default for Search AO3 and JSONL/zip import. Requires the ao3kit '
            'checkout and network access for uncached tags. Collapses AO3 '
            'synonyms and appends metatags (e.g. Marvel for Spider-Man). Extra '
            'collection and tag rules are under Collections & tag rules in '
            'the plugin menu (.ao3kit/mappings.yaml).'
        )
        defaults_form.addRow(self.simplify_tags)

        self.update_existing = QCheckBox(
            'Update existing books matched by AO3 work id or URL'
        )
        self.update_existing.setChecked(bool(prefs.get('update_existing', True)))
        defaults_form.addRow(self.update_existing)

        self.import_full_series = QCheckBox(
            'Always import the rest of the series when adding a series work'
        )
        self.import_full_series.setChecked(bool(prefs.get('import_full_series', False)))
        self.import_full_series.setToolTip(
            'Whenever Search AO3, Search similar, a series URL, or JSONL/zip '
            'import adds a work that is part of an AO3 series, also fetch and '
            'import every other part. Search filters do not apply to those '
            'extra works. Can add many books and EPUB downloads.'
        )
        defaults_form.addRow(self.import_full_series)
        layout.addWidget(defaults)

        runtime = QGroupBox('ao3kit')
        runtime_form = QFormLayout(runtime)
        self.ao3kit_project = QLineEdit()
        self.ao3kit_project.setText(prefs.get('ao3kit_project') or '')
        self.ao3kit_project.setPlaceholderText('/Users/you/emily/ao3')
        runtime_form.addRow('Project path', self.ao3kit_project)
        runtime_form.addRow(
            _hint('Folder containing the ao3kit package (the git checkout).')
        )
        self.ao3kit_python = QLineEdit()
        self.ao3kit_python.setText(prefs.get('ao3kit_python') or '')
        self.ao3kit_python.setPlaceholderText('/path/to/python3')
        runtime_form.addRow('Python', self.ao3kit_python)
        runtime_form.addRow(
            _hint('Optional. Default is python3 on PATH, then the project venv.')
        )
        layout.addWidget(runtime)

        self.refresh_status()

    def test_login(self) -> None:
        username = self.username.text().strip()
        password = self.password.text()
        if not username or not password:
            error_dialog(
                self,
                'AO3 Scraper',
                'Enter both username and password, then click Test login.',
                show=True,
            )
            return

        from calibre_plugins.ao3_scraper.enrich import EnrichCancelled, run_ao3kit
        from calibre_plugins.ao3_scraper.prefs import prefs as plugin_prefs
        from calibre_plugins.ao3_scraper.scrape_run import build_login_test_argv

        saved_project = plugin_prefs.get('ao3kit_project') or ''
        saved_python = plugin_prefs.get('ao3kit_python') or ''
        plugin_prefs['ao3kit_project'] = self.ao3kit_project.text().strip()
        plugin_prefs['ao3kit_python'] = self.ao3kit_python.text().strip()

        self.login_status.setText('Testing AO3 login…')
        self.test_login_btn.setEnabled(False)
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            code, stdout, stderr = run_ao3kit(
                build_login_test_argv(username, password),
            )
        except EnrichCancelled:
            self.login_status.setText('')
            return
        finally:
            plugin_prefs['ao3kit_project'] = saved_project
            plugin_prefs['ao3kit_python'] = saved_python
            QApplication.restoreOverrideCursor()
            self.test_login_btn.setEnabled(True)

        if code == 0:
            summary = f'Logged in as {username}.'
            self.login_status.setText(summary)
            info_dialog(self, 'AO3 Scraper', summary, show=True)
            return

        detail = (stderr or stdout or f'exit {code}').strip()
        self.login_status.setText('Login failed.')
        error_dialog(
            self,
            'AO3 Scraper',
            'AO3 login failed. Check the username and password.',
            det_msg=detail,
            show=True,
        )

    def sizeHint(self):
        return QSize(560, 860)

    def refresh_status(self):
        db = self.plugin_action.gui.current_db
        present = layout_columns_present(db)
        parts = []
        for spec in LAYOUT_COLUMN_SPECS:
            mark = 'yes' if present.get(spec['role']) else 'missing'
            parts.append(f"{spec['lookup']} {mark}")
        self.status.setText('Current library: ' + ', '.join(parts) + '.')

    def save_settings(self):
        gui = self.plugin_action.gui
        if self.create_layout.isChecked():
            apply_layout_columns(gui)
        prefs['setup_complete'] = True
        prefs['ao3kit_project'] = self.ao3kit_project.text().strip()
        prefs['ao3kit_python'] = self.ao3kit_python.text().strip()
        prefs['ao3_username'] = self.username.text().strip()
        prefs['ao3_password'] = self.password.text()
        prefs['last_max_results'] = self.max_results.text().strip() or '25'
        prefs['download_epubs'] = self.download_epubs.isChecked()
        prefs['simplify_tags'] = self.simplify_tags.isChecked()
        prefs['update_existing'] = self.update_existing.isChecked()
        prefs['import_full_series'] = self.import_full_series.isChecked()
        self.create_layout.setChecked(False)
        self.refresh_status()

    def validate(self):
        username = self.username.text().strip()
        password = self.password.text()
        if (username and not password) or (password and not username):
            error_dialog(
                self,
                'AO3 Scraper',
                'Both username and password are required to log in to AO3 '
                '(or leave both blank to use .env / anonymous).',
                show=True,
            )
            return False
        return True
