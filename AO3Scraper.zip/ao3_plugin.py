# -*- coding: utf-8 -*-

from __future__ import annotations

import shutil
import traceback
from contextlib import contextmanager

from PyQt5.Qt import QApplication, QCursor, QMenu, Qt

from calibre.gui2 import error_dialog, info_dialog
from calibre.gui2.actions import InterfaceAction

from calibre_plugins.ao3_scraper.columns import ensure_plugin_columns
from calibre_plugins.ao3_scraper.dialogs import ImportJsonlDialog
from calibre_plugins.ao3_scraper.importer import import_records
from calibre_plugins.ao3_scraper.jsonl_loader import load_import_source
from calibre_plugins.ao3_scraper.prefs import prefs

try:
    load_translations()
except NameError:
    pass


@contextmanager
def busy_cursor():
    QApplication.setOverrideCursor(QCursor(Qt.WaitCursor))
    try:
        yield
    finally:
        QApplication.restoreOverrideCursor()


class AO3ScraperPlugin(InterfaceAction):
    name = 'AO3 Scraper'
    action_spec = ('AO3 Scraper', None, 'Import AO3 JSONL or EPUB zip', None)

    def genesis(self):
        self.qaction.triggered.connect(self.show_import_dialog)
        self.menu = QMenu(self.gui)
        self.qaction.setMenu(self.menu)
        self.menu.aboutToShow.connect(self.build_menu)

    def initialization_complete(self):
        ensure_plugin_columns(self.gui.current_db)
        prefs['setup_complete'] = True

    def build_menu(self):
        self.menu.clear()
        self.menu.addAction('Import JSONL or zip...', self.show_import_dialog)
        self.menu.addAction('Plugin settings...', self.show_configuration)

    def apply_settings(self):
        ensure_plugin_columns(self.gui.current_db)

    def show_import_dialog(self):
        dialog = ImportJsonlDialog(self.gui)
        if not dialog.exec_():
            return

        values = dialog.values()
        if not values['path']:
            error_dialog(self.gui, 'AO3 Scraper', 'Choose a JSONL or import zip file.', show=True)
            return

        prefs['last_jsonl_path'] = values['path']

        cleanup_dir = None
        try:
            with busy_cursor():
                records, bundle_root, cleanup_dir = load_import_source(values['path'])
                if not records:
                    raise ValueError('The import file contains no records.')

                db = self.gui.current_db
                ensure_plugin_columns(db)
                outcomes = import_records(
                    db,
                    records,
                    update_existing=values['update_existing'],
                    bundle_root=str(bundle_root) if bundle_root else None,
                )
        except Exception:
            error_dialog(
                self.gui,
                'AO3 Scraper',
                'Import failed.',
                det_msg=traceback.format_exc(),
                show=True,
            )
            return
        finally:
            if cleanup_dir:
                shutil.rmtree(cleanup_dir, ignore_errors=True)

        added = sum(1 for x in outcomes if x['action'] == 'added')
        updated = sum(1 for x in outcomes if x['action'] == 'updated')
        skipped = sum(1 for x in outcomes if x['action'] == 'skipped')
        epubs = sum(1 for x in outcomes if x.get('epub'))
        info_dialog(
            self.gui,
            'AO3 Scraper',
            (
                f'Imported {len(outcomes)} works '
                f'({added} added, {updated} updated, {skipped} skipped'
                f'{f", {epubs} with EPUB" if epubs else ""}).'
            ),
            show=True,
        )
        self.gui.library_view.model().refresh()
