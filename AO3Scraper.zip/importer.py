# -*- coding: utf-8 -*-
"""Import AO3 JSONL records into a Calibre library."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from calibre.ebooks.metadata import MetaInformation

from calibre_plugins.ao3_scraper.cleaned import (
    book_matches_work,
    calibre_fields_for_record,
    canonical_work_id,
    canonical_work_url,
    tags_for_calibre_library,
    work_url,
)
from calibre_plugins.ao3_scraper.columns import (
    custom_label_is_live,
    layout_columns_present,
)
from calibre_plugins.ao3_scraper.jsonl_loader import resolve_epub_path


def build_metadata(
    record: dict[str, Any],
    *,
    layout: dict[str, bool] | None = None,
    existing_identifiers: dict[str, Any] | None = None,
    existing_comments: str | None = None,
) -> MetaInformation:
    fields = calibre_fields_for_record(record)
    work_id = fields['work_id']
    title = record.get('title') or f'AO3 work {work_id or "?"}'
    author = record.get('author')
    authors = [author] if author else ['Unknown']

    mi = MetaInformation(title, authors)
    identifiers = dict(existing_identifiers or {})
    identifiers.update(fields['identifiers'])
    mi.set_identifiers(identifiers)

    if fields.get('series'):
        mi.series = fields['series']
        index = fields.get('series_index')
        mi.series_index = float(index) if index is not None else 1.0

    present = layout or {}
    mi.tags = tags_for_calibre_library(
        record,
        has_fandom_column=bool(present.get('fandom')),
        has_relationships_column=bool(present.get('relationships')),
        has_collections_column=bool(present.get('collections')),
    )

    # Leave Comments alone (AO3 summaries live there; scrape records have no summary).
    if existing_comments:
        mi.comments = existing_comments
    return mi


def find_existing_book(db, record: dict[str, Any]) -> int | None:
    work_id = canonical_work_id(record)
    url = canonical_work_url(record)
    search = getattr(db, 'search_getting_ids', None)
    queries: list[str] = []
    if work_id:
        queries.append(f'identifiers:ao3:{work_id}')
        queries.append(f'identifiers:url:"{work_url(work_id)}"')
        queries.append(
            f'identifiers:url:"https://www.archiveofourown.org/works/{work_id}"'
        )
    if url:
        queries.append(f'identifiers:url:"{url}"')

    if search is not None:
        for query in queries:
            try:
                ids = search(query, None, use_virtual_library=False)
            except Exception:
                continue
            if ids:
                return ids[0]

    for book_id in db.all_ids():
        ids = db.get_identifiers(book_id, index_is_id=True) or {}
        if book_matches_work(ids, work_id=work_id, url=url):
            return book_id
    return None


def find_book_by_work_id(db, work_id: str) -> int | None:
    return find_existing_book(db, {'work_id': work_id})


def add_epub_format(db, book_id: int, epub_path: Path) -> bool:
    db.add_format(book_id, 'EPUB', str(epub_path), index_is_id=True)
    return True


def attach_downloaded_epubs(
    db,
    items: list[dict[str, Any]],
    *,
    bundle_root: str | Path | None,
) -> list[dict[str, Any]]:
    """Add downloaded EPUB files onto existing books. Does not rewrite metadata."""
    outcomes: list[dict[str, Any]] = []
    for item in items:
        book_id = item['book_id']
        record = item.get('record') or {}
        title = record.get('title') or item.get('title')
        if bundle_root is None:
            outcomes.append(
                {
                    'book_id': book_id,
                    'title': title,
                    'action': 'failed',
                    'reason': 'no download folder',
                    'epub': False,
                }
            )
            continue
        epub_path = resolve_epub_path(record, bundle_root)
        if epub_path is None:
            outcomes.append(
                {
                    'book_id': book_id,
                    'title': title,
                    'action': 'failed',
                    'reason': record.get('epub_error') or 'no EPUB file',
                    'epub': False,
                }
            )
            continue
        add_epub_format(db, book_id, epub_path)
        outcomes.append(
            {
                'book_id': book_id,
                'title': title,
                'action': 'added',
                'epub': True,
            }
        )
    return outcomes


def set_book_tags(db, book_id: int, tags: list[str]) -> None:
    """Replace the standard Tags field used by Calibre's tag browser."""
    cleaned = [str(tag).strip() for tag in tags if str(tag).strip()]
    api = getattr(db, 'new_api', None)
    if api is not None and hasattr(api, 'set_field'):
        api.set_field('tags', {int(book_id): cleaned})
        return
    setter = getattr(db, 'set_tags', None)
    if setter is not None:
        setter(book_id, cleaned, append=False)
        commit = getattr(db, 'commit', None)
        if callable(commit):
            commit()
        return
    mi = db.get_metadata(book_id, index_is_id=True)
    mi.tags = cleaned
    try:
        db.set_metadata(book_id, mi, force_changes=True)
    except TypeError:
        db.set_metadata(book_id, mi)


def _set_custom(db, book_id: int, label: str, value: Any, *, commit: bool) -> bool:
    """Write a custom column if it is live. Skip rather than KeyError."""
    label = str(label).lstrip('#')
    if not custom_label_is_live(db, label):
        return False
    lookup = f'#{label}'
    api = getattr(db, 'new_api', None)
    if api is not None and hasattr(api, 'set_field'):
        api.set_field(lookup, {int(book_id): value})
        return True
    db.set_custom(book_id, value, label=label, commit=commit)
    return True


def write_layout_fields(db, book_id: int, record: dict[str, Any]) -> None:
    """Write FanFicFare-style columns when they exist. Skip missing columns."""
    fields = calibre_fields_for_record(record)
    present = layout_columns_present(db)

    if present.get('fandom') and fields['fandoms']:
        _set_custom(db, book_id, 'fandom', fields['fandoms'], commit=False)
    if present.get('relationships') and fields['relationships']:
        _set_custom(
            db, book_id, 'relationships', fields['relationships'], commit=False
        )
    if present.get('collections') and fields['collections']:
        _set_custom(
            db, book_id, 'collections', fields['collections'], commit=False
        )
    if present.get('wordcount') and fields['wordcount'] is not None:
        _set_custom(db, book_id, 'wordcount', fields['wordcount'], commit=False)
    if present.get('originaltags') and fields['original_tags']:
        _set_custom(
            db, book_id, 'originaltags', fields['original_tags'], commit=False
        )

    commit = getattr(db, 'commit', None)
    if callable(commit):
        commit()


def refresh_library_ui(gui, book_ids: list[int] | None = None) -> None:
    """Refresh the book list and tag browser after Tags field changes."""
    model = gui.library_view.model()
    if book_ids and hasattr(model, 'refresh_ids'):
        try:
            model.refresh_ids(list(book_ids))
        except Exception:
            model.refresh()
    else:
        model.refresh()
    tags_view = getattr(gui, 'tags_view', None)
    if tags_view is not None and hasattr(tags_view, 'recount'):
        tags_view.recount()


def import_record(
    db,
    record: dict[str, Any],
    *,
    update_existing: bool = True,
    bundle_root: str | Path | None = None,
    skip_existing_epub: bool = False,
) -> dict[str, Any]:
    layout = layout_columns_present(db)
    existing_id = find_existing_book(db, record)

    if existing_id is not None and not update_existing:
        return {
            'book_id': existing_id,
            'action': 'skipped',
            'title': record.get('title'),
            'epub': False,
        }

    existing_identifiers = None
    existing_comments = None
    if existing_id is not None:
        try:
            existing = db.get_metadata(existing_id, index_is_id=True)
            existing_identifiers = existing.get_identifiers()
            existing_comments = existing.comments
        except Exception:
            pass

    mi = build_metadata(
        record,
        layout=layout,
        existing_identifiers=existing_identifiers,
        existing_comments=existing_comments,
    )

    if existing_id is None:
        book_id = db.create_book_entry(mi, add_duplicates=True)
        action = 'added'
    else:
        book_id = existing_id
        try:
            db.set_metadata(book_id, mi, force_changes=True)
        except TypeError:
            db.set_metadata(book_id, mi)
        action = 'updated'

    write_layout_fields(db, book_id, record)
    set_book_tags(db, book_id, mi.tags)

    attached = False
    if bundle_root is not None:
        already_has_epub = False
        if skip_existing_epub:
            try:
                already_has_epub = bool(
                    db.has_format(book_id, 'EPUB', index_is_id=True)
                )
            except Exception:
                already_has_epub = False
        if not already_has_epub:
            epub_path = resolve_epub_path(record, bundle_root)
            if epub_path is not None:
                attached = add_epub_format(db, book_id, epub_path)

    return {
        'book_id': book_id,
        'action': action,
        'title': record.get('title'),
        'epub': attached,
    }


def import_records(
    db,
    records: list[dict[str, Any]],
    *,
    update_existing: bool = True,
    bundle_root: str | Path | None = None,
    skip_existing_epub: bool = False,
) -> list[dict[str, Any]]:
    return [
        import_record(
            db,
            record,
            update_existing=update_existing,
            bundle_root=bundle_root,
            skip_existing_epub=skip_existing_epub,
        )
        for record in records
    ]
